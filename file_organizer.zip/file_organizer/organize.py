#!/usr/bin/env python3
"""
File Organizer - Automatically sort files into categorized folders.
Usage:
    python organize.py                        # Organizes ~/Downloads
    python organize.py /path/to/folder        # Organizes a specific folder
    python organize.py --dry-run              # Preview without moving anything
    python organize.py --undo                 # Undo the last organize run
    python organize.py --force                # Skip all safety prompts (use carefully)
"""

import argparse
import json
import shutil
import sys
from datetime import datetime
from pathlib import Path

# ── Default category → extensions mapping ─────────────────────────────────────
DEFAULT_RULES: dict[str, list[str]] = {
    "Images":        [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp", ".tiff", ".heic", ".raw"],
    "Videos":        [".mp4", ".mov", ".avi", ".mkv", ".wmv", ".flv", ".webm", ".m4v", ".mpg", ".mpeg"],
    "Audio":         [".mp3", ".wav", ".flac", ".aac", ".ogg", ".wma", ".m4a", ".opus", ".aiff"],
    "Documents":     [".pdf", ".doc", ".docx", ".txt", ".odt", ".rtf", ".md", ".pages"],
    "Spreadsheets":  [".xls", ".xlsx", ".csv", ".ods", ".numbers"],
    "Presentations": [".ppt", ".pptx", ".odp", ".key"],
    "Archives":      [".zip", ".tar", ".gz", ".bz2", ".7z", ".rar", ".xz", ".tgz"],
    "Code":          [".py", ".js", ".ts", ".html", ".css", ".java", ".c", ".cpp", ".h",
                      ".go", ".rs", ".rb", ".php", ".sh", ".bat", ".ps1", ".sql", ".json",
                      ".yaml", ".yml", ".toml", ".xml", ".swift", ".kt"],
    "Executables":   [".exe", ".msi", ".dmg", ".pkg", ".deb", ".rpm", ".appimage"],
    "Fonts":         [".ttf", ".otf", ".woff", ".woff2", ".eot"],
    "Ebooks":        [".epub", ".mobi", ".azw", ".azw3", ".djvu"],
}

# ── Safety: executable / system-critical extensions ───────────────────────────
RISKY_EXTENSIONS: set[str] = {
    ".exe", ".dll", ".sys", ".drv", ".ocx",   # Windows binaries
    ".so", ".dylib",                           # Linux / macOS libraries
    ".bat", ".cmd", ".ps1", ".vbs",            # Windows scripts
    ".sh", ".bash", ".zsh",                    # Unix scripts
    ".msi", ".dmg", ".pkg", ".appimage",       # Installers
    ".deb", ".rpm",                            # Linux packages
    ".ini", ".cfg", ".reg",                    # Config / registry
    ".pak", ".dat", ".bin", ".cache",          # Common game data files
}

# ── Safety: game-signature filenames & extensions ─────────────────────────────
GAME_SIGNATURE_FILES: set[str] = {
    "steam_appid.txt", "steamclient.dll", "steamclient64.dll",
    "unins000.exe", "uninstall.exe", "uninstaller.exe",
    "gameoverlayrenderer.dll", "gameoverlayrenderer64.dll",
    "ue4prereqsetup_x64.exe", "ue4prereqsetup_x86.exe",  # Unreal Engine
    "vcredist_x64.exe", "vcredist_x86.exe",              # Common game prereqs
    "dxsetup.exe", "dotnetfx.exe",
}

GAME_SIGNATURE_EXTENSIONS: set[str] = {
    ".pak", ".uasset", ".umap", ".upk",    # Unreal Engine
    ".gcf", ".ncf",                         # Steam cache
    ".vpk",                                 # Valve Pack
    ".forge", ".big",                       # Ubisoft / EA
    ".bsa", ".esm", ".esp", ".esl",        # Bethesda (Skyrim, Fallout, etc.)
    ".wad", ".pk3", ".pk4",                # id Software / Quake
    ".mpq",                                 # Blizzard (StarCraft, WoW, Diablo)
    ".arc", ".bnk",                         # Capcom / Wwise audio banks
    ".nif", ".kf",                          # NetImmerse / Gamebryo
    ".unity3d", ".assets",                  # Unity
}

# ── Safety: protected / dangerous base directories ────────────────────────────
PROTECTED_PATHS: list[Path] = [
    # Windows
    Path("C:/Windows"),
    Path("C:/Program Files"),
    Path("C:/Program Files (x86)"),
    Path("C:/ProgramData"),
    Path("C:/Users/Default"),
    # Common game install roots
    Path("C:/Program Files/Steam"),
    Path("C:/Program Files (x86)/Steam"),
    Path("C:/GOG Games"),
    Path("C:/Epic Games"),
    # macOS
    Path("/Applications"),
    Path("/System"),
    Path("/Library"),
    Path("/usr"),
    Path("/bin"),
    Path("/sbin"),
    # Linux
    Path("/usr"),
    Path("/etc"),
    Path("/opt"),
    Path("/bin"),
    Path("/sbin"),
    Path("/lib"),
    Path("/lib64"),
    # Home sub-dirs that should never be bulk-sorted
    Path.home() / "Library",
    Path.home() / ".steam",
    Path.home() / ".local/share/Steam",
]

UNDO_LOG = Path.home() / ".file_organizer_undo.json"


# ── Safety checks ─────────────────────────────────────────────────────────────

def check_protected_path(folder: Path) -> None:
    """Abort if the folder is (or is inside) a protected system/game path."""
    resolved = folder.resolve()
    for protected in PROTECTED_PATHS:
        try:
            resolved.relative_to(protected.resolve())
            print(f"\n  ✗  BLOCKED: '{resolved}' is inside a protected directory:")
            print(f"     {protected}")
            print("     Organising here could break installed software or games.")
            print("     If you really mean this folder, copy files out first.")
            sys.exit(1)
        except ValueError:
            pass  # not a sub-path — fine


def check_game_signatures(folder: Path) -> None:
    """Warn and abort if the folder looks like a game installation directory."""
    hits: list[str] = []

    for f in folder.iterdir():
        name_lower = f.name.lower()
        ext_lower  = f.suffix.lower()

        if f.is_file():
            if name_lower in GAME_SIGNATURE_FILES:
                hits.append(f"  • '{f.name}' (known game/engine file)")
            elif ext_lower in GAME_SIGNATURE_EXTENSIONS:
                hits.append(f"  • '{f.name}' ({ext_lower} — game data format)")

        if len(hits) >= 3:   # 3 hits is enough evidence; stop scanning
            break

    if hits:
        print("\n  ⚠  WARNING: This folder looks like a game or engine installation!")
        print("     Detected:")
        for h in hits:
            print(f"    {h}")
        print("\n     Moving files here could break the game / application.")
        answer = input("\n     Continue anyway? [y/N] ").strip().lower()
        if answer != "y":
            print("  Aborted — no files were moved.")
            sys.exit(0)


def check_risky_files(folder: Path, force: bool = False) -> bool:
    """
    Warn if the folder contains executables or system-critical files.
    Returns True if the user confirms they want to proceed, False to skip those files.
    """
    risky = [f for f in folder.iterdir() if f.is_file() and f.suffix.lower() in RISKY_EXTENSIONS]
    if not risky:
        return True  # nothing risky — full speed ahead

    print(f"\n  ⚠  Found {len(risky)} executable / system-critical file(s):")
    for f in risky[:10]:
        print(f"    • {f.name}")
    if len(risky) > 10:
        print(f"    … and {len(risky) - 10} more")

    print("\n     Moving these could break installed programs or games.")

    if force:
        print("     --force flag set — proceeding anyway.")
        return True

    print("\n     What would you like to do?")
    print("     [s] Skip risky files, organise everything else  (recommended)")
    print("     [m] Move them anyway")
    print("     [q] Quit")
    choice = input("\n     Choice [s/m/q]: ").strip().lower()

    if choice == "m":
        return True   # move everything including risky files
    elif choice == "s":
        return False  # skip risky files
    else:
        print("  Aborted — no files were moved.")
        sys.exit(0)


def check_no_recursion(folder: Path) -> None:
    """
    Remind the user (once) that only top-level files are moved.
    Sub-folders are never touched.
    """
    subdirs = [d for d in folder.iterdir() if d.is_dir()]
    if subdirs:
        print(f"\n  ℹ  Note: {len(subdirs)} sub-folder(s) found and will NOT be touched.")
        print("     Only loose files at the top level of this folder will be moved.")


# ── Helpers ───────────────────────────────────────────────────────────────────

def load_rules(config_path: Path | None) -> dict[str, list[str]]:
    if config_path and config_path.exists():
        with open(config_path) as f:
            custom = json.load(f)
        print(f"  Using config: {config_path}")
        return custom
    return DEFAULT_RULES


def ext_to_category(rules: dict[str, list[str]]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for category, exts in rules.items():
        for ext in exts:
            mapping[ext.lower()] = category
    return mapping


def safe_destination(dest_dir: Path, filename: str) -> Path:
    dest = dest_dir / filename
    if not dest.exists():
        return dest
    stem, suffix = Path(filename).stem, Path(filename).suffix
    counter = 1
    while dest.exists():
        dest = dest_dir / f"{stem}_{counter}{suffix}"
        counter += 1
    return dest


# ── Core logic ────────────────────────────────────────────────────────────────

def organize(
    folder: Path,
    rules: dict[str, list[str]],
    dry_run: bool = False,
    skip_unknown: bool = False,
    move_risky: bool = True,
) -> list[dict]:
    mapping = ext_to_category(rules)
    moves: list[dict] = []
    skipped_risky: list[str] = []
    unknown_files: list[str] = []

    files = [f for f in folder.iterdir() if f.is_file()]
    if not files:
        print("  No files found — nothing to do.")
        return moves

    print(f"\n  Scanning {len(files)} file(s) in: {folder}\n")

    for file in sorted(files):
        # Skip risky files if the user chose not to move them
        if not move_risky and file.suffix.lower() in RISKY_EXTENSIONS:
            skipped_risky.append(file.name)
            continue

        category = mapping.get(file.suffix.lower())

        if category is None:
            if skip_unknown:
                unknown_files.append(file.name)
                continue
            category = "Other"

        dest_dir = folder / category
        dest = safe_destination(dest_dir, file.name)

        label = "(dry run) " if dry_run else ""
        print(f"  {label}{file.name}  →  {category}/")

        if not dry_run:
            dest_dir.mkdir(exist_ok=True)
            shutil.move(str(file), str(dest))

        moves.append({"src": str(dest), "dst": str(file)})

    if skipped_risky:
        print(f"\n  Skipped {len(skipped_risky)} risky file(s) (left in place):")
        for name in skipped_risky:
            print(f"    • {name}")

    if unknown_files:
        print(f"\n  Skipped {len(unknown_files)} file(s) with unrecognised extensions:")
        for name in unknown_files:
            print(f"    • {name}")

    return moves


def save_undo_log(moves: list[dict]) -> None:
    log = {"timestamp": datetime.now().isoformat(), "moves": moves}
    with open(UNDO_LOG, "w") as f:
        json.dump(log, f, indent=2)
    print(f"\n  Undo log saved → {UNDO_LOG}")


def undo_last_run() -> None:
    if not UNDO_LOG.exists():
        print("  No undo log found. Nothing to undo.")
        return

    with open(UNDO_LOG) as f:
        log = json.load(f)

    moves: list[dict] = log["moves"]
    ts = log.get("timestamp", "unknown time")
    print(f"\n  Undoing {len(moves)} move(s) from {ts}\n")

    errors = 0
    dst = None
    for move in moves:
        src, dst = Path(move["src"]), Path(move["dst"])
        if not src.exists():
            print(f"  ✗  Missing: {src}")
            errors += 1
            continue
        print(f"  ↩  {src.name}  →  {dst.parent.name}/")
        shutil.move(str(src), str(dst))

    if dst:
        parent = dst.parent
        for d in parent.iterdir():
            if d.is_dir() and not any(d.iterdir()):
                d.rmdir()
                print(f"  Removed empty folder: {d.name}/")

    UNDO_LOG.unlink()
    result = "complete" if not errors else f"done with {errors} error(s)"
    print(f"\n  Undo {result}.")


# ── CLI ───────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Automatically organise files into categorised sub-folders.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "folder", nargs="?",
        default=str(Path.home() / "Downloads"),
        help="Folder to organise (default: ~/Downloads)",
    )
    parser.add_argument("--dry-run", "-n", action="store_true",
                        help="Preview moves without touching any files")
    parser.add_argument("--undo", action="store_true",
                        help="Undo the last organise run")
    parser.add_argument("--config", "-c", type=Path, default=None,
                        help="Path to a custom JSON rules file (see rules.json)")
    parser.add_argument("--skip-unknown", action="store_true",
                        help="Leave files with unrecognised extensions in place")
    parser.add_argument("--force", action="store_true",
                        help="Skip all safety prompts — use carefully!")

    args = parser.parse_args()

    print("\n┌─────────────────────────────────┐")
    print("│        File Organizer 1.1        │")
    print("└─────────────────────────────────┘")

    if args.undo:
        undo_last_run()
        return

    folder = Path(args.folder).expanduser().resolve()
    if not folder.exists():
        print(f"\n  Error: folder not found — {folder}")
        sys.exit(1)
    if not folder.is_dir():
        print(f"\n  Error: path is not a directory — {folder}")
        sys.exit(1)

    # ── Safety gauntlet ───────────────────────────────────────────────────────
    if not args.force:
        check_protected_path(folder)          # 1. Block protected system/game paths
        check_game_signatures(folder)         # 2. Detect game installations
        check_no_recursion(folder)            # 3. Remind: sub-folders are never touched

    move_risky = True
    if not args.dry_run and not args.force:
        move_risky = check_risky_files(folder)  # 4. Confirm before moving executables

    # ── Organise ──────────────────────────────────────────────────────────────
    rules = load_rules(args.config)
    moves = organize(
        folder, rules,
        dry_run=args.dry_run,
        skip_unknown=args.skip_unknown,
        move_risky=move_risky,
    )

    if moves and not args.dry_run:
        save_undo_log(moves)
        print(f"\n  ✓  Organised {len(moves)} file(s) successfully.")
    elif args.dry_run:
        print(f"\n  Dry-run complete — {len(moves)} file(s) would be moved.")
    else:
        print("\n  Nothing was moved.")


if __name__ == "__main__":
    main()
