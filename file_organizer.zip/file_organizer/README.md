# 📁 File Organizer

Automatically sort a messy folder into tidy sub-folders — by file type — in one command.  
**No dependencies beyond Python 3.10+.** Works on macOS, Windows, and Linux.

---

## Quick Start

```bash
# Organise your Downloads folder (default)
python organize.py

# Organise any folder
python organize.py ~/Desktop

# Preview what WOULD happen — no files are touched
python organize.py --dry-run

# Undo the last run
python organize.py --undo
```

---

## What It Does

Loose files are moved into sub-folders by type:

```
Downloads/
├── Images/          ← .jpg .png .gif .heic …
├── Videos/          ← .mp4 .mov .mkv …
├── Audio/           ← .mp3 .flac .wav …
├── Documents/       ← .pdf .docx .txt …
├── Spreadsheets/    ← .xlsx .csv …
├── Presentations/   ← .pptx .key …
├── Archives/        ← .zip .7z .tar.gz …
├── Code/            ← .py .js .html …
├── Executables/     ← .exe .dmg .deb …
├── Fonts/           ← .ttf .otf .woff …
├── Ebooks/          ← .epub .mobi …
└── Other/           ← anything unrecognised
```

Sub-folders already inside the target are **never touched** — only loose files
at the top level are moved.

---

## All Options

| Flag | Description |
|------|-------------|
| `folder` | Path to organise (default: `~/Downloads`) |
| `--dry-run` / `-n` | Show every planned move, touch nothing |
| `--undo` | Reverse the last run, restore original locations |
| `--config FILE` / `-c` | Use a custom `rules.json` category map |
| `--skip-unknown` | Leave unrecognised files in place (skip `Other/`) |
| `--force` | Bypass all safety prompts — use with care |

---

## Safety Features

The script runs a gauntlet of checks before moving anything:

### 1 · Protected Path Blocking
Certain directories are **permanently blocked** — the script will refuse to run
and exit immediately if you point it at:

- System directories: `C:\Windows`, `/System`, `/usr`, `/etc` …
- Program installs: `C:\Program Files`, `/Applications`, `/opt` …
- Game roots: `C:\Program Files\Steam`, `C:\GOG Games`, `C:\Epic Games`,
  `~/.steam`, `~/.local/share/Steam` …

To add your own blocked paths, edit the `PROTECTED_PATHS` list in `organize.py`.

### 2 · Game Installation Detection
Before moving anything, the script scans for known game/engine file signatures:

| Engine / Platform | Detected formats |
|---|---|
| Unreal Engine | `.pak` `.uasset` `.umap` `.upk` |
| Unity | `.unity3d` `.assets` |
| Bethesda (Skyrim, Fallout …) | `.bsa` `.esm` `.esp` `.esl` |
| Blizzard (WoW, StarCraft …) | `.mpq` |
| id Software / Quake | `.wad` `.pk3` `.pk4` |
| Valve / Steam | `.vpk` `.gcf` `steam_appid.txt` |
| Ubisoft / EA | `.forge` `.big` |
| Wwise audio banks | `.bnk` |

If **3 or more** matching files are found, a warning is shown and you must
type `y` to continue.

### 3 · Executable & System File Confirmation
If the folder contains `.exe`, `.dll`, `.bat`, `.pak`, `.bin`, or other
system-critical extensions, you are prompted to choose:

```
[s] Skip risky files, organise everything else  (recommended)
[m] Move them anyway
[q] Quit
```

Skipped files are left exactly where they are.

### 4 · Recursion Guard
Sub-folders are **never entered or modified**. Only files sitting directly
inside the target folder are considered. A notice is printed if sub-folders
are present, so there are no surprises.

---

## Custom Rules

Copy `rules.json` and edit it to define your own categories:

```json
{
  "Work":    [".docx", ".xlsx", ".pptx", ".pdf"],
  "Photos":  [".jpg", ".jpeg", ".heic", ".raw"],
  "Music":   [".mp3", ".flac", ".wav", ".aiff"]
}
```

Pass it with `--config`:

```bash
python organize.py ~/Desktop --config my_rules.json
```

The custom file completely replaces the built-in rules, so include every
extension you care about.

---

## Undo

Every successful run saves a log to `~/.file_organizer_undo.json`.

```bash
python organize.py --undo
```

This moves every file back to its original location and removes any empty
category folders that were created. The log is deleted after a successful undo.

> **Note:** Only one level of undo is stored. Running the organiser a second
> time overwrites the previous undo log.

---

## Collision Handling

No files are ever overwritten. If a file with the same name already exists in
the destination folder, a numeric suffix is appended automatically:

```
report.pdf   → already exists
report_1.pdf → already exists
report_2.pdf → used ✓
```

---

## Requirements

- Python **3.10** or newer
- No third-party packages

---

## Tips

- Always run `--dry-run` first on an unfamiliar folder.
- Organising your `~/Downloads` folder is the safest and most useful use case.
- Never point the script at a game install folder — use the game launcher to
  manage those files instead.
- Add the script to your `PATH` (or a cron job / Task Scheduler) to keep
  Downloads tidy automatically.
